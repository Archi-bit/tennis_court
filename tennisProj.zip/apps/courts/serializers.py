from rest_framework import serializers
from .models import * 
from apps.news.serializers import GalleryImageSerializer



class CourtTypeSerializer(serializers.ModelSerializer):
    courts_count = serializers.SerializerMethodField()

    class Meta:
        model = CourtType
        fields = '__all__'

    def get_courts_count(self, obj):
        return obj.court_type.count()


class CourtListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Court
        fields = ('id', 'court_number', 'is_active')


class CourtDetailSerializer(serializers.ModelSerializer):
    court_type = CourtTypeSerializer(read_only=True)

    gallery_images = GalleryImageSerializer(source='courts', many=True, read_only=True)

    class Meta:
        model = Court
        fields = ('id', 'court_number', 'court_type', 'is_active', 'description', 'gallery_images')